package com.prem.lingofloat

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

class MainActivity : AppCompatActivity() {

    private lateinit var progress: ProgressBar
    private lateinit var statusIcon: ImageView
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView

    private val overlayLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) askCapture()
        }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, TranslatorService::class.java)
                    .putExtra("code", result.resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                moveTaskToBack(true)
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progress = findViewById(R.id.progress)
        statusIcon = findViewById(R.id.statusIcon)
        statusTitle = findViewById(R.id.statusTitle)
        statusSub = findViewById(R.id.statusSub)

        findViewById<View>(R.id.btnStart).setOnClickListener { begin() }
        findViewById<View>(R.id.btnStop).setOnClickListener {
            startService(Intent(this, TranslatorService::class.java).setAction("STOP"))
        }
        findViewById<View>(R.id.statusCard).setOnClickListener {
            if (progress.visibility != View.VISIBLE && statusIcon.visibility != View.VISIBLE) {
                prepareModel()
            }
        }

        if (Build.VERSION.SDK_INT >= 33) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        prepareModel()
    }

    private fun prepareModel() {
        progress.visibility = View.VISIBLE
        statusIcon.visibility = View.GONE
        statusTitle.text = "Getting Indonesian ready..."
        statusSub.text = "One-time download, then it works offline"

        val tr = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.INDONESIAN)
                .setTargetLanguage(TranslateLanguage.ENGLISH)
                .build()
        )
        tr.downloadModelIfNeeded()
            .addOnSuccessListener {
                progress.visibility = View.GONE
                statusIcon.visibility = View.VISIBLE
                statusTitle.text = "Ready to translate"
                statusSub.text = "Indonesian \u2192 English works offline"
                tr.close()
            }
            .addOnFailureListener {
                progress.visibility = View.GONE
                statusIcon.visibility = View.GONE
                statusTitle.text = "Download failed"
                statusSub.text = "Check your internet, then tap here to try again"
                tr.close()
            }
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            overlayLauncher.launch(i)
            return
        }
        askCapture()
    }

    private fun askCapture() {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(mgr.createScreenCaptureIntent())
    }
}
