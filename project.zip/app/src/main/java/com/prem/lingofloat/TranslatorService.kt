package com.prem.lingofloat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

private class Item(val rect: Rect, val src: String, var out: String? = null)

class TranslatorService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var idleReader: ImageReader? = null
    private var pendingReader: ImageReader? = null
    private var button: ImageView? = null
    private var overlay: FrameLayout? = null
    private var w = 0
    private var h = 0
    private var dpi = 0
    private var busy = false

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var translatorRef: Translator? = null

    private fun translator(): Translator {
        val existing = translatorRef
        if (existing != null) return existing
        val t = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.INDONESIAN)
                .setTargetLanguage(TranslateLanguage.ENGLISH)
                .build()
        )
        translatorRef = t
        return t
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (projection != null) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            intent?.getParcelableExtra("data")
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        w = m.widthPixels
        h = m.heightPixels
        dpi = m.densityDpi

        try {
            startCapture(code, data)
        } catch (e: Exception) {
            toast("Couldn't start: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
        addButton()
        toast("LingoFloat is on. Tap the bubble to translate")
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("lingo", "LingoFloat", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, TranslatorService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_delete), "Stop", stopIntent
        ).build()
        val n = Notification.Builder(this, "lingo")
            .setContentTitle("LingoFloat is on")
            .setContentText("Tap the floating bubble to translate your screen")
            .setSmallIcon(R.drawable.ic_translate)
            .addAction(stopAction)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mgr.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        projection = p

        val idle = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        idle.setOnImageAvailableListener({ r -> r.acquireLatestImage()?.close() }, main)
        idleReader = idle
        display = p.createVirtualDisplay(
            "lingofloat", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, idle.surface, null, null
        )
    }

    private fun addButton() {
        val size = dp(54)
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.ic_translate)
            val pad = dp(14)
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF4F46E5.toInt(), 0xFF06B6D4.toInt())
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0xFFFFFFFF.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(240)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var downTime = 0L
        iv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = lp.x
                    oy = lp.y
                    moved = false
                    downTime = e.eventTime
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (e.eventTime - downTime > 800) stopSelf() else capture()
                    }
                    true
                }
                else -> false
            }
        }
        wm.addView(iv, lp)
        button = iv
    }

    private fun capture() {
        if (busy) return
        busy = true
        removeOverlay()
        button?.visibility = View.INVISIBLE
        main.postDelayed({
            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            pendingReader = reader
            reader.setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                val bmp = try {
                    toBitmap(img)
                } finally {
                    img.close()
                }
                finishCapture(reader)
                button?.alpha = 0.5f
                recognize(bmp)
            }, main)
            display?.surface = reader.surface
            main.postDelayed({
                if (pendingReader === reader) {
                    finishCapture(reader)
                    toast("Couldn't capture the screen, try again")
                    done()
                }
            }, 3000)
        }, 250)
    }

    private fun finishCapture(reader: ImageReader) {
        pendingReader = null
        reader.setOnImageAvailableListener(null, null)
        display?.surface = idleReader?.surface
        reader.close()
        button?.visibility = View.VISIBLE
    }

    private fun done() {
        busy = false
        button?.alpha = 1f
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val rowPadding = p.rowStride - p.pixelStride * w
        val wide = Bitmap.createBitmap(w + rowPadding / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(p.buffer)
        return Bitmap.createBitmap(wide, 0, 0, w, h)
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t ->
                val items = ArrayList<Item>()
                for (b in t.textBlocks) {
                    val r = b.boundingBox ?: continue
                    val c = clean(b.text)
                    if (!worthIt(c)) continue
                    items.add(Item(r, c))
                }
                if (items.isEmpty()) {
                    toast("No text found on screen")
                    done()
                    return@addOnSuccessListener
                }
                translator().downloadModelIfNeeded()
                    .addOnSuccessListener {
                        var left = items.size
                        for (item in items) {
                            translator().translate(item.src)
                                .addOnSuccessListener { res -> item.out = res }
                                .addOnCompleteListener {
                                    left--
                                    if (left == 0) showOverlay(bmp, items)
                                }
                        }
                    }
                    .addOnFailureListener {
                        toast("Open LingoFloat once with internet to get the Indonesian pack")
                        done()
                    }
            }
            .addOnFailureListener {
                toast("Couldn't read the screen")
                done()
            }
    }

    // Join the lines of a bubble into one sentence, fix ALL CAPS, so the translator gets clean text.
    private fun clean(raw: String): String {
        var s = raw.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        s = s.replace(Regex("(?<=\\p{L})-\\s+(?=\\p{L})"), "-")
        val letters = s.count { it.isLetter() }
        val upper = s.count { it.isUpperCase() }
        if (letters >= 3 && upper * 10 > letters * 6) s = sentenceCase(s)
        return s
    }

    private fun sentenceCase(s: String): String {
        val sb = StringBuilder()
        var cap = true
        for (c in s.lowercase()) {
            if (cap && c.isLetter()) {
                sb.append(c.uppercaseChar())
                cap = false
            } else {
                sb.append(c)
            }
            if (c == '.' || c == '!' || c == '?') cap = true
        }
        return sb.toString()
    }

    // Skip clocks, battery, page numbers and other non-text noise.
    private fun worthIt(s: String): Boolean {
        val letters = s.count { it.isLetter() }
        val chars = s.count { !it.isWhitespace() }
        if (letters < 2 || chars == 0) return false
        return letters.toFloat() / chars.toFloat() >= 0.5f
    }

    private fun sampleBg(bmp: Bitmap, r: Rect): Int {
        val xs = intArrayOf(r.left + 3, (r.left + r.right) / 2, r.right - 3)
        val ys = intArrayOf(r.top + 3, (r.top + r.bottom) / 2, r.bottom - 3)
        var rr = 0
        var gg = 0
        var bb = 0
        var n = 0
        for (xi in xs.indices) {
            for (yi in ys.indices) {
                if (xi == 1 && yi == 1) continue
                val px = bmp.getPixel(xs[xi].coerceIn(0, bmp.width - 1), ys[yi].coerceIn(0, bmp.height - 1))
                rr += Color.red(px)
                gg += Color.green(px)
                bb += Color.blue(px)
                n++
            }
        }
        return Color.rgb(rr / n, gg / n, bb / n)
    }

    private fun showOverlay(bmp: Bitmap, items: List<Item>) {
        val root = FrameLayout(this)
        var count = 0
        for (item in items) {
            val out = item.out ?: continue
            if (out.trim().equals(item.src.trim(), ignoreCase = true)) continue
            val r = item.rect
            val pad = dp(4)
            val left = (r.left - pad).coerceIn(0, w - 1)
            val top = (r.top - pad).coerceIn(0, h - 1)
            val bw = (r.width() + pad * 2).coerceAtMost(w - left).coerceAtLeast(dp(24))
            val bh = (r.height() + pad * 2).coerceAtMost(h - top).coerceAtLeast(dp(16))
            val bg = sampleBg(bmp, r)
            val lum = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000
            val tv = TextView(this)
            tv.text = out
            tv.background = GradientDrawable().apply {
                setColor(bg)
                cornerRadius = dp(8).toFloat()
            }
            tv.setTextColor(if (lum > 140) Color.BLACK else Color.WHITE)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(3), dp(1), dp(3), dp(1))
            tv.includeFontPadding = false
            tv.setAutoSizeTextTypeUniformWithConfiguration(7, 22, 1, TypedValue.COMPLEX_UNIT_SP)
            val lp = FrameLayout.LayoutParams(bw, bh)
            lp.leftMargin = left
            lp.topMargin = top
            root.addView(tv, lp)
            count++
        }
        if (count == 0) {
            toast("Nothing to translate here")
            done()
            return
        }
        root.setOnClickListener { removeOverlay() }
        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(root, params)
        overlay = root
        done()
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        removeOverlay()
        button?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        button = null
        display?.release()
        idleReader?.close()
        projection?.stop()
        recognizer.close()
        translatorRef?.close()
        super.onDestroy()
    }
}
