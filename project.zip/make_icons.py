import os
from PIL import Image, ImageDraw

RES = "app/src/main/res"


def default_logo():
    n = 512
    img = Image.new("RGBA", (n, n))
    d = ImageDraw.Draw(img)
    a = (79, 70, 229)
    b = (6, 182, 212)
    for y in range(n):
        t = y / (n - 1)
        c = tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)
        d.line([(0, y), (n, y)], fill=c)
    d.rounded_rectangle([110, 130, 402, 340], radius=48, fill="white")
    d.polygon([(190, 330), (190, 400), (260, 335)], fill="white")
    for i, wd in enumerate([230, 170]):
        y = 190 + i * 50
        d.rounded_rectangle([140, y, 140 + wd, y + 22], radius=11, fill=(79, 70, 229))
    return img


logo = None
for name in sorted(os.listdir(".")):
    low = name.lower()
    if low.startswith("logo.") and low.rsplit(".", 1)[-1] in ("png", "jpg", "jpeg", "webp"):
        try:
            logo = Image.open(name).convert("RGBA")
            print("Using logo:", name)
            break
        except Exception as e:
            print("Could not read", name, e)

if logo is None:
    print("No logo found, using the default one")
    logo = default_logo()

w, h = logo.size
s = min(w, h)
left = (w - s) // 2
top = (h - s) // 2
logo = logo.crop((left, top, left + s, top + s))

# background colour for the adaptive icon = colour of the logo's corner
px = logo.getpixel((4, 4))
if px[3] < 128:
    bg = (79, 70, 229)
else:
    bg = px[:3]

os.makedirs(RES + "/drawable-nodpi", exist_ok=True)
os.makedirs(RES + "/values", exist_ok=True)

logo.resize((512, 512), Image.LANCZOS).save(RES + "/drawable-nodpi/logo.png")

canvas = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
small = logo.resize((288, 288), Image.LANCZOS)
canvas.paste(small, (72, 72), small)
canvas.save(RES + "/drawable-nodpi/ic_launcher_foreground.png")

with open(RES + "/values/icon_colors.xml", "w") as f:
    f.write('<resources>\n    <color name="icon_bg">#%02X%02X%02X</color>\n</resources>\n' % bg)

print("Icons done, background colour", bg)
