package com.premjoy.lingofloat

import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        const val ACTION_CAPTURE_NOW = "com.premjoy.lingofloat.CAPTURE_NOW"
        private const val CHANNEL_ID = "lingofloat_capture"
        private const val NOTIFICATION_ID = 41
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val busy = AtomicBoolean(false)
    private var lastProcessed = 0L
    private var recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.INDONESIAN)
            .setTargetLanguage(TranslateLanguage.ENGLISH)
            .build()
    )
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            captureNext = true
        }
    }
    @Volatile private var captureNext = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val filter = IntentFilter(ACTION_CAPTURE_NOW)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("LingoFloat is active")
            .setContentText("Screen translation session is running. Tap the floating bubble to translate.")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                   else @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_DATA) as? Intent)
        if (projection == null && data != null) startProjection(resultCode, data)
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ imageReader ->
            val now = System.currentTimeMillis()
            val shouldProcess = captureNext || now - lastProcessed > 2500
            if (!shouldProcess || !busy.compareAndSet(false, true)) {
                imageReader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            captureNext = false
            lastProcessed = now
            val image = imageReader.acquireLatestImage()
            if (image == null) { busy.set(false); return@setOnImageAvailableListener }
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width
            val fullBitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
            fullBitmap.copyPixelsFromBuffer(plane.buffer)
            image.close()
            val bitmap = Bitmap.createBitmap(fullBitmap, 0, 0, width, height)
            fullBitmap.recycle()
            processBitmap(bitmap)
        }, handler)

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        virtualDisplay = projection?.createVirtualDisplay(
            "LingoFloatScreen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
    }

    private fun processBitmap(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val text = result.text.trim()
                if (text.isBlank()) {
                    Toast.makeText(this, "No readable text found on screen", Toast.LENGTH_SHORT).show()
                    busy.set(false)
                } else {
                    translator.downloadModelIfNeeded()
                        .addOnSuccessListener {
                            translator.translate(text)
                                .addOnSuccessListener { translated ->
                                    showTranslation(translated)
                                    busy.set(false)
                                }
                                .addOnFailureListener { showError(it); busy.set(false) }
                        }
                        .addOnFailureListener { showError(it); busy.set(false) }
                }
            }
            .addOnFailureListener { showError(it); busy.set(false) }
            .addOnCompleteListener { bitmap.recycle() }
    }

    private fun showTranslation(text: String) {
        handler.post {
            Toast.makeText(this, text.take(220), Toast.LENGTH_LONG).show()
            val intent = Intent(this, TranslationResultActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("translation", text)
            }
            startActivity(intent)
        }
    }

    private fun showError(error: Exception) {
        handler.post { Toast.makeText(this, "Translation error: ${error.localizedMessage}", Toast.LENGTH_LONG).show() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "LingoFloat screen translation", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
