package com.premjoy.lingofloat

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class TranslationResultActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent.getStringExtra("translation") ?: "No translation available"
        val view = TextView(this).apply {
            this.text = "LingoFloat • English\n\n$text\n\nTap Back to return"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(24, 24, 24, 24)
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFF211B38.toInt())
                cornerRadius = 28f
                setStroke(2, 0xFF8B5CF6.toInt())
            }
        }
        setContentView(view)
        window.setLayout(
            (resources.displayMetrics.widthPixels * .88f).toInt(),
            android.view.WindowManager.LayoutParams.WRAP_CONTENT
        )
        window.setBackgroundDrawableResource(android.R.color.transparent)
    }
}
