package com.premjoy.lingofloat

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Ink = Color(0xFF101020)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF5EEAD4)

class MainActivity : ComponentActivity() {
    private val projectionRequest = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Violet,
                    secondary = Cyan,
                    background = Ink,
                    surface = Color(0xFF1B1B30)
                )
            ) {
                LingoHome(
                    onEnableBubble = { enableBubble() },
                    onStartCapture = { requestCapture() },
                    onStopCapture = { stopService(Intent(this, ScreenCaptureService::class.java)) }
                )
            }
        }
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        } else {
            startService(Intent(this, FloatingBubbleService::class.java))
        }
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == Activity.RESULT_OK && data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, data)
            }
            ContextCompat.startForegroundService(this, service)
        }
    }
}

@Composable
private fun LingoHome(
    onEnableBubble: () -> Unit,
    onStartCapture: () -> Unit,
    onStopCapture: () -> Unit
) {
    var autoMode by remember { mutableStateOf(false) }
    var source by remember { mutableStateOf("Indonesian") }
    var target by remember { mutableStateOf("English") }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF111126), Color(0xFF21143B), Color(0xFF101020)))
        )
    ) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(16.dp), color = Violet.copy(alpha = .2f)) {
                    Icon(Icons.Default.Translate, null, tint = Cyan, modifier = Modifier.padding(13.dp).size(28.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("LingoFloat", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("See it. Tap it. Understand it.", color = Color.LightGray)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF24213D))) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("YOUR TRANSLATION", color = Cyan, style = MaterialTheme.typography.labelLarge)
                    Text("$source  →  $target", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Default language pair. More languages can be added in a future update.", color = Color.LightGray)
                }
            }

            Text("QUICK ACTIONS", color = Color.LightGray, style = MaterialTheme.typography.labelLarge)
            Button(onClick = onEnableBubble, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Icon(Icons.Default.BubbleChart, null)
                Spacer(Modifier.width(8.dp))
                Text("Enable floating bubble")
            }
            OutlinedButton(onClick = onStartCapture, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Icon(Icons.Default.ScreenshotMonitor, null)
                Spacer(Modifier.width(8.dp))
                Text("Start screen translation")
            }
            OutlinedButton(onClick = onStopCapture, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.StopCircle, null)
                Spacer(Modifier.width(8.dp))
                Text("Stop screen capture")
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF24213D))) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Automatic mode", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Translate new screen text while capture is active.", color = Color.LightGray)
                        }
                        Switch(checked = autoMode, onCheckedChange = {
                            autoMode = it
                            if (it) onStartCapture() else onStopCapture()
                        })
                    }
                    Text(
                        "Manual mode: start capture, then tap the floating bubble to translate the current screen. Automatic mode: the app checks the screen periodically while the capture session is running.",
                        color = Color.LightGray,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF24213D))) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Privacy first", color = Cyan, fontWeight = FontWeight.Bold)
                    Text("Android displays its own screen-sharing prompt. Capturing stops when you stop the session. Avoid capturing passwords, payment details, or private information.", color = Color.LightGray)
                }
            }
            Text("LingoFloat • Version 1.0.0", color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
