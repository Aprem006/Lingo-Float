# LingoFloat

**See it. Tap it. Understand it.**

LingoFloat is an Android floating screen translator prototype. The first build focuses on Indonesian-to-English translation using on-device ML Kit OCR and translation.

## Features in this starter build

- Jetpack Compose home screen
- Draggable floating bubble overlay
- Android MediaProjection screen capture with system consent
- ML Kit text recognition
- ML Kit Indonesian-to-English on-device translation
- GitHub Actions workflow to build a debug APK

## Build an APK with GitHub

1. Upload this entire project to a GitHub repository.
2. Open **Actions** in the repository.
3. Select **Build LingoFloat APK**.
4. Tap **Run workflow** (or push a commit to `main`).
5. Open the completed workflow run.
6. Download the `LingoFloat-debug-apk` artifact.
7. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Important prototype notes

- This is an early prototype, not a production-ready release.
- Android will show its system screen-capture consent prompt. Screen capture must be started by the user.
- The current automatic mode checks screen frames periodically while the capture session is active. Manual mode uses the floating bubble to request a translation of the latest frame.
- The floating bubble requires the Android **Display over other apps** permission.
- Translation uses the Indonesian and English ML Kit language models. The first use may need an internet connection to download the model.
- Some apps may block screenshots or screen capture. Secure/password/payment screens should not be captured.
- The result is currently shown in an app window and a notification-style Toast; a polished draggable translation card, language selector, history, pause/resume controls, and robust lifecycle handling are planned next.

## Technical stack

- Kotlin
- Android SDK 35
- Jetpack Compose / Material 3
- Google ML Kit Text Recognition
- Google ML Kit Translation
- MediaProjection API
- GitHub Actions

## Version

`1.0.0-prototype`
